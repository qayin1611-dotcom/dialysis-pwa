
function plasmaFlow(Qb, Hct) {
  return Qb * (1 - Hct / 100);
}

function filtrationFraction(Qb, Hct, Quf, Qpre) {
  let Qp = plasmaFlow(Qb, Hct);
  let Qp_hr = Qp * 60;
  let FF = Quf / (Qp_hr + Qpre);
  return FF;
}

function riskAssessment(FF) {
  if (FF >= 0.25) return "🔴 HIGH RISK (>25%)";
  if (FF >= 0.20) return "🟡 WARNING (20–25%)";
  return "🟢 OPTIMAL (<20%)";
}

function calculate() {
  let Qb = parseFloat(document.getElementById("qb").value);
  let Hct = parseFloat(document.getElementById("hct").value);
  let Quf = parseFloat(document.getElementById("quf").value);
  let Qpre = parseFloat(document.getElementById("qpre").value) || 0;
  let subvol = parseFloat(document.getElementById("subvol").value) || 0;
  let mode = document.getElementById("mode").value;

  if (isNaN(Qb) || isNaN(Hct) || isNaN(Quf)) {
    document.getElementById("result").innerHTML = "Inserire valori validi.";
    return;
  }

  let Qp = plasmaFlow(Qb, Hct);
  let FF = filtrationFraction(Qb, Hct, Quf, Qpre);
  let FF_percent = (FF * 100).toFixed(2);
  let risk = riskAssessment(FF);

  let hv = "";
  if (mode.includes("HDF")) {
    hv = subvol >= 22 ? "High-Volume HDF ✅" : "Standard HDF";
  }

  document.getElementById("result").innerHTML =
    `Mode: ${mode}<br>
     Plasma Flow: ${Qp.toFixed(2)} mL/min<br>
     Filtration Fraction: ${FF_percent}%<br>
     Risk: ${risk}<br>
     ${hv}`;
}

function convert() {
  let mmol = parseFloat(document.getElementById("mmol").value);
  let mw = parseFloat(document.getElementById("mw").value);

  if (isNaN(mmol) || isNaN(mw)) {
    document.getElementById("conversion").innerText = "Valori non validi.";
    return;
  }

  let mgdl = (mmol * mw / 10).toFixed(3);
  document.getElementById("conversion").innerText = mgdl + " mg/dL";
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("service-worker.js");
}
